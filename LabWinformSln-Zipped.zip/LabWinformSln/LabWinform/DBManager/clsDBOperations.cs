﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWinform.DBManager 
{
    class clsDBOperations
    {
        static String connectionString = @"Data Source=TEJASM\SQLEXPRESS;Initial Catalog=ICCA2021;Integrated Security=True";

        public static int insertStudentDetails(clsStudent clsStudentObject)
        {
           SqlConnection connectionObject = new SqlConnection(connectionString);
           connectionObject.Open();
           String queryToExecute = "INSERT INTO TBL_STUDENT VALUES('" + clsStudentObject.usn + "','" + clsStudentObject.name + "','" + clsStudentObject.collegeName + "'," + clsStudentObject.degree + "," + clsStudentObject.gender + "," + clsStudentObject.isCovidVacinated + ")";
           SqlCommand commandObject = new SqlCommand(queryToExecute, connectionObject);
           int result = commandObject.ExecuteNonQuery();
           connectionObject.Close();
           return result;
       }
        public static int deleteStudentDetails(int slno)
        {

            SqlConnection connectionObject = new SqlConnection(connectionString);
            connectionObject.Open();
            String queryToExecute = "DELETE FROM TBL_STUDENT WHERE SLNO = " + slno;
            SqlCommand commandObject = new SqlCommand(queryToExecute, connectionObject);
            int result = commandObject.ExecuteNonQuery();
            connectionObject.Close();
            return result;

        }
        public static int updateStudentDetails(clsStudent clsStudentObject)
        {

            SqlConnection connectionObject = new SqlConnection(connectionString);
            connectionObject.Open();
            String queryToExecute = "UPDATE TBL_STUDENT SET  USN = '" + clsStudentObject.usn + "', NAME = '" + clsStudentObject.name + "',COLLEGENAME = '" + clsStudentObject.collegeName + "',DEGREE = " + clsStudentObject.degree + ", GENDER = " + clsStudentObject.gender + ", ISCVACINATED = " + clsStudentObject.isCovidVacinated + " WHERE SLNO = " + clsStudentObject.slno;
            SqlCommand commandObject = new SqlCommand(queryToExecute, connectionObject);
            int result = commandObject.ExecuteNonQuery();
            connectionObject.Close();
            return result;
        }
        
        public static DataTable getStudentDetails()
        {

            DataTable dt = new DataTable();

            dt.Columns.Add("Slno", typeof(int));
            dt.Columns.Add("USN", typeof(string));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("CollegeName", typeof(string));
            dt.Columns.Add("Degree", typeof(string));
            dt.Columns.Add("Gender", typeof(string));
            dt.Columns.Add("ISCVACINATED", typeof(string));
           
            

            SqlConnection connectionObject = new SqlConnection(connectionString);
            connectionObject.Open();
            String queryToExecute = "SELECT * FROM TBL_STUDENT";

            SqlCommand commandObject = new SqlCommand(queryToExecute, connectionObject);
            SqlDataReader sdr = commandObject.ExecuteReader();
            while(sdr.Read())
            {
                DataRow dr = dt.NewRow();
                dr["Slno"] = sdr["Slno"];
                dr["USN"] = sdr["USN"];
                dr["Name"] = sdr["Name"];
                dr["CollegeName"] = sdr["CollegeName"];
                dr["Degree"] = returnDegree(Convert.ToInt32(sdr["Degree"]));
                dr["Gender"] = returnGender(Convert.ToInt32(sdr["Gender"]));
                dr["ISCVACINATED"] = Convert.ToInt32(sdr["ISCVACINATED"]) == 1 ? "Yes":"No";
                dt.Rows.Add(dr);  
            }

            return dt;
        }
        private static String returnDegree(int id)
        {
            if (id == 1)
                return "BCA";
            else if (id == 2)
                return "BSC(CS)";
            else if (id == 3)
                return "BE(CS)";
            else 
                return "BCA";

        }
        private static String returnGender(int id)
        {
            if (id == 1)
                return "Male";
            else if (id == 2)
                return "FeMale";
            else if (id == 3)
                return "Other";
            else
                return "Male";

        }
        public static DataTable getDegreeDetails()
        {
            DataTable dt = new DataTable();
            SqlConnection connectionObject = new SqlConnection(connectionString);
            connectionObject.Open();
            String queryToExecute = "SELECT * FROM TBL_DEGREE";
            SqlCommand commandObject = new SqlCommand(queryToExecute,connectionObject);
            SqlDataReader sdr = commandObject.ExecuteReader();
            dt.Load(sdr);
            return dt;
         
        }
      
       
    }
    
}
