﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWinform
{
    class clsStudent
    {
        public int slno { get; set; }
        public String usn { get; set; }
        public String name { get; set; }
        public String collegeName { get; set; }
        public int degree { get; set; }
        public int gender { get; set; }
        public int isCovidVacinated { get; set;}
    }
}
